# Play Habibi - Telegram Mini App (TWA) & Ad Locker Web App

Yeh web app aapke uploaded video me dikhaye gaye **Play Habibi / Tera Video Bot** Mini App ka complete replicate hai.

### Features Included:
1. **Telegram Web App UI & Mobile Layout**: Dark theme (`#0a0f1d`), header bar, search bar, and category filter chips.
2. **2-Column Video Cards Grid**: 8 viral/teaser video cards with matching titles, duration badges, and "Watch Video" buttons.
3. **Ad-Gated Interstitial (Ad Locker)**:
   - Countdown timer (12s default, customizable)
   - Real ad creative (CBTF2X / 2up.app)
   - Interactive progress bar (0% -> 100%)
   - Skip / Fast Test mode
4. **Loading State**: Circular glowing gradient spinner + "Loading Your Video... Please wait while we prepare your experience".
5. **Unlocked Modal**:
   - Deep-link generator: `https://t.me/Tera_video_26bot?start=...`
   - One-click copy link button
   - "Open in App" button
   - "Watch in Built-in Web Player" button
6. **In-App Media Player**: Built-in video player with scrubber, time display, play/pause, volume, and fullscreen.
7. **Bot & Ad Config Panel (⚙️ Settings)**:
   - Change Bot Name
   - Change destination Telegram Bot link
   - Change Ad countdown duration (0s Instant, 3s, 5s, 12s, 20s)
   - Add custom video cards with custom start tokens

### Deployment / Hosting:
- **Cloudflare Pages / Vercel / GitHub Pages**: Simply upload `index.html`.
- **Telegram Bot Integration**:
  1. Open `@BotFather` on Telegram.
  2. Run `/newapp` or `/mybots` -> Select your bot -> **Bot Settings** -> **Menu Button** -> **Configure menu button**.
  3. Enter your hosted web app URL (e.g. `https://your-domain.com/`).
